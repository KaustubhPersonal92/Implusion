
module.exports = {
    //This is your MYSQL Database configuration    
    modelsDir : {
        path : __dirname + '/../models'
    },
    // "live-db": {
    //     "username": 'admin',
    //     "password": 'admin123',
    //     "database": 'impulsion',
    //     "host": '34.220.168.152',
    //     "dialect": 'mysql',
    //     "port": '3306'
    // }

    "db": {
        "username": 'root',
        "password": '12345678',
        "database": 'implusion',
        "host": 'localhost',
        "dialect": 'mysql',
        "port": '3306'
    }

};
